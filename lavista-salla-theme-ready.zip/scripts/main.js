// Basic interactions
document.addEventListener('DOMContentLoaded', function(){
  const btn = document.querySelector('.mobile-menu-btn');
  const nav = document.querySelector('.main-nav');
  if(btn) btn.addEventListener('click', () => nav.classList.toggle('open'));
});